# service-tom

> Recommended restaurants page of Zagat

## Related Projects

  - https://github.com/hrr42-fec5/service-allen
  - https://github.com/hrr42-fec5/service-camryn
  - https://github.com/hrr42-fec5/service-alex

## Table of Contents

1. [Usage](#Usage)
2. [Development](#development)

## Usage

> Some usage instructions

## Development

### Installing Dependencies

From within the root directory:

```sh
npm install -g webpack
npm install
```
