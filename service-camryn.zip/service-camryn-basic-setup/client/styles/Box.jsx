import React from 'react';
import styled from 'styled-components';

export default styled.section`
  padding: 15px 40px 15px 40px;
  background-color: rgb(255,255,255);
  width: 750px;
  text-align: center;
`;