import React from 'react';
import styled from 'styled-components';

export default styled.div`
  align: left;
  margin: 0px 0px 50px 0px
  display: inline-block;
  width: 375px;
  height: 100px;
  overflow-wrap: break-word;
  cursor: pointer;
`;